from Classes.Packets.PiranhaMessage import PiranhaMessage
from Database.DatabaseHandler import ClubDatabaseHandler
from Classes.Stream.StreamEntryFactory import StreamEntryFactory
import json

class AllianceStreamMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields, player):
        db_instance = ClubDatabaseHandler
        self.writeVInt(1)
        self.writeVInt(2) #Event
        self.writeVInt(0)
        self.writeVInt(1) #NumEvent
        self.writeVInt(0)#High ID
        self.writeVInt(1)#Low ID
        self.writeString('SparkyDev')#Name
        self.writeVInt(2) #Role
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeString(f'Your account:\nName: {player.Name}\nToken: {player.Token}\nLow ID: {player.ID[1]}')

    def decode(self):
        return {}

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 24311

    def getMessageVersion(self):
        return self.messageVersion